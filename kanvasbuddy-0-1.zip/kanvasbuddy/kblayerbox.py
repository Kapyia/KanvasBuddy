# The KanvasBuddy Krita plugin is licensed under CC BY-NC-SA 4.0

# You are free to:
# Share — copy and redistribute the material in any medium or format
# Adapt — remix, transform, and build upon the material

# Under the following terms:
# Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
# NonCommercial — You may not use the material for commercial purposes.
# ShareAlike — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
# No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import QSize, Qt

class KBLayerItem(QWidget): # Unfinished, unused

    def __init__(self, node=None):
        super(KBLayerItem, self).__init__()
        self.setLayout(QHBoxLayout(self))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.node = node
        self.layout().setContentsMargins(0, 0, 0, 0)

        self.layout().addWidget(QToolButton())
        self.layout().addWidget(QLabel('Layer Placeholder'))
    
    def setNode(self, node):
        self.node = node

    def node(self):
        return self.node    


class KBLayerBox(QScrollArea):

    def __init__(self):
        super(KBLayerBox, self).__init__()
        self.setBackgroundRole(QPalette.Base)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setWidgetResizable(True)
        self.nodes = []

        self.layerList = QWidget(self)
        self.layerList.setLayout(QVBoxLayout())
        self.layerList.layout().setContentsMargins(0, 0, 0, 0)
        self.layerList.layout().setSpacing(0)
        self.layerList.layout().setAlignment(Qt.AlignTop)

        self.setWidget(self.layerList)

    def addLayer(self, node=None):
        self.nodes.append(node)
        self.layerList.layout().addWidget(KBLayerItem())

class KBLayerWidget(QWidget):

    def __init__(self, parent):
        super(KBLayerWidget, self).__init__(parent)
        self.setLayout(QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(0)

        self.layerBox = KBLayerBox()
        self.btn_addLayer = QPushButton('Add')
        self.btn_addLayer.clicked.connect(self.addLayer)

        self.layout().addWidget(self.layerBox)
        self.layout().addWidget(self.btn_addLayer)

    def addLayer(self):
        self.layerBox.addLayer()

    def sizeHint(self):
        return QSize(150, 200)
        


